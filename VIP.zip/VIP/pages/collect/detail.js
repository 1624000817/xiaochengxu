
Page({

  data: {
  
  },

  appointmentForm(e){
    
    
        
    if (e.detail.value.name == false || e.detail.value.name == undefined) {
      wx.showModal({
        content: '请输入姓名',
        showCancel: false
      })
      return;
    };
    if (e.detail.value.name.length>8){
      wx.showModal({
        content: '请输入八字以内',
        showCancel: false
      })
      return;
    }
    if (!/^(13[0-9]|15[0-9]|18[0-9]|14[0-9]|17[0-9])\d{8}$/.test(e.detail.value.mobile)) {
      wx.showModal({
        content: '手机号格式错误！',
        showCancel: false
      })
      return;
    };
    wx.showLoading({
      title: '提交中',
      mask: true
    })
  }
})