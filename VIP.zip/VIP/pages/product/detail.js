import newData from '../../Datas/m.js';

Page({
    data:{
      imgurl: [],
      open: false
    },


    open(e) {
      this.setData({
        open: true
      })
    },
    close(e) {
      this.setData({
        open: false
      })
    },





    phoneTap: function(e){ //拨打电话
        getApp().globalData.phone(e);
    },
    onLoad: function(params){


      var L = this.data.imgurl.length;
      this.setData({
        all: L
      })

        let _this = this;
        let param = {
            API_URL: getApp().globalData.yt_base_url+'getTypeData.html?pageType=product_detail&domain='+getApp().globalData.extInfo.domain+'&id='+params.id
        };
        
        newData.result(param).then( data => {
            let datas = data.data.data;

            this.setData({
                d: datas,
                global: getApp().globalData.d(),
                'global.link': true,
                'global.currentId': 'product'
            })

            wx.setNavigationBarTitle({
                title: this.data.d.title
            })

        }).catch(e => {
            console.error(e);
        });
    },
    onReady: function(){
 
    },
    onShareAppMessage: function(res) {
        if (res.from === 'button') {
            // 来自页面内转发按钮
        }
        return {
            title: this.data.d.title,
            //path: '/page/user?id=123',
            success: function(res) {
                // 转发成功
            },
            fail: function(res) {
                // 转发失败
            }
        }
    }
})