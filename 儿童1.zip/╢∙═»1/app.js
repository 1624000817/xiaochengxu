var gData;
App(
	{
   
		onLaunch: function () {
			wx.showNavigationBarLoading();
			var that = this
			if(!wx.getExtConfig) {
				wx.showModal({
					title: '提示',
					content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试!'
				});
			} else {
				that.globalData.extInfo = wx.getExtConfigSync() ? wx.getExtConfigSync() : {};
			}

			that.checkYunque();
		},
		checkYunque: function() {
			var that = this
			wx.request({
				url: that.globalData.yt_base_url+'getNavs.html?domain='+that.globalData.extInfo.domain+'&app_id='+that.globalData.extInfo.extAppid,
				data: {
				},
				header: {
					'content-type': 'application/json'
				},
				success: function(res) {
					gData = res.data.data
					// 云雀客服
					if(gData.yunque_exists) {
						wx.login({
							success: function (res) {
							if (res.code) {
							  var code = res.code;
							  wx.getUserInfo({
								withCredentials: true,
								success: function (res) {
								  wx.request({
									url: "https://api.yunque360.com/v1/publicapi/miniapp/userinfo",
									method: "POST",
									data: {
									  appid: that.globalData.extInfo.extAppid,//此处的appid请替换！
									  code: code,
									  rawData: res.rawData,
									  signature: res.signature
									}
								  });
								}
							  });
							}
						  }
						});
					}
				}
			})
		},
		onShow: function () {
			
		},
		initNav:function(cb) {
			var that = this
			if(gData){
				typeof cb == "function" && cb()
			}else{
				wx.request({
					url: that.globalData.yt_base_url+'getNavs.html?domain='+that.globalData.extInfo.domain+'&app_id='+that.globalData.extInfo.extAppid,
					data: {
					},
					header: {
						'content-type': 'application/json'
					},
					success: function(res) {
						gData = res.data.data
						wx.hideNavigationBarLoading();
						typeof cb == "function" && cb()
					}
				})
			}
		},
		onHide: function () {
		},
		globalData: {
			yt_base_url:'https://x.yingtaoyun.cn/yt/miniprogramRequest/',
			// yt_base_url:'http://www.yun2.com/yt/miniprogramRequest/',
			extInfo:null,
			d: function(){
				return gData;
			},
			phone: function(e) {
				wx.makePhoneCall({
					phoneNumber: e.currentTarget.dataset.phone
				})
			}
		}
	}
)

