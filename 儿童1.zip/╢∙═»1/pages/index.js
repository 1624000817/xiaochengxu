import newData from '../Datas/m.js';

Page({
    data: {
        currentId: 'home',
        title: '首页',
        autoplay: true,
        vertical: true,
        circular: true,
        current: 1,
        display:"none",
        _num:0,
        
        imgdata:[
          {
        name: "Mr. C & Mrs. D",
        picUrl:  "http://productimg.yingtaoyun.com/93/ee/93eee8ae3549a2a1e89e63255d085495.jpg!w640",
url:"/pages/show/detail?id=5515",
isChecked: false
        },
          {
            name: "Mr. E & Mrs. F",
            picUrl: "http://productimg.yingtaoyun.com/08/c6/08c6934c76270d386d1da3643af677ca.jpg!w640",
            url: "/pages/show/detail?id=5517",
            isChecked: false
          },
          {
            name: "Mr. C & Mrs. D",
            picUrl: "http://productimg.yingtaoyun.com/93/ee/93eee8ae3549a2a1e89e63255d085495.jpg!w640",
            url: "/pages/show/detail?id=5515",
            isChecked: false
          }
        ]
    },
    setPage: function(title){ //设置页面标题
        wx.setNavigationBarTitle({ title: title});
    },
    phoneTap: function(e){ //拨打电话
        getApp().globalData.phone(e);
    },
    loadPage: function(title,url){ //载入频道页
        let _this = this;
        let param = {
            API_URL: url
        };

        newData.result(param).then( data => {
            let datas = data.data.data;
            this.setPage(title);
            this.setData({
                d: datas,
                title: title
            })
        }).catch(e => {
            console.error(e);
        });
    },
    name(e){
      let num = e.target.dataset.num;
      this.setData({

        _num:num
      })
    },
    collect(e){

    let param = {};
     let index=e.target.dataset.index;
     let string = 'imgdata[' + index + '].isChecked';
     console.log(string)
     param[string] = this.data.imgdata[index].isChecked;
     param[string]=true;
     console.log(param[string])
      this.setData(param);
      },
    categoryTap: function(e){ //分类菜单
        let i = e.currentTarget.id;
        this.setData({
            'global.current': i,
            'd.categoryData.s':''
         });
        let kk = '';
        if(this.data.currentId == 'show') {
            kk = 'keywords'
        } else {
            kk = 'gid';
        }
        this.loadPage(e.currentTarget.dataset.name,getApp().globalData.yt_base_url+'getTypeData.html?pageType='+this.data.currentId+'&domain='+getApp().globalData.extInfo.domain+'&'+kk+'='+i);
    },

    customerTap: function(e){
        wx.navigateTo({
            url: e.currentTarget.dataset.url
        })
    },
    onLoad: function(params){
        if(params.type!='tap'){
            if(params.go){
                this.data.currentId = params.go;
            }
        }else{
            this.data.currentId = params.currentTarget.id
        }

        let that = this
        getApp().initNav(function() {
            let type_label = 'nav_'+that.data.currentId+'_label';
            that.loadPage(getApp().globalData.d()[type_label], getApp().globalData.yt_base_url+'getTypeData.html?pageType='+that.data.currentId+'&domain='+getApp().globalData.extInfo.domain+'&app_id='+getApp().globalData.extInfo.extAppid);
        });
        
    },
    handleTap: function(e){
        let id = e.currentTarget.id;
        if(id){
            this.setData({ 
                'global.currentId': id,
                'global.current':''
            })
            this.onLoad(e);
        }
    },
    offerItem: function(e){ //报价项目选择
        let type = this.data.d.offerData[e.target.dataset.index].type;
     
        let param = {};
        if(type == 0){
            let arr = this.data.d.offerData[e.target.dataset.index].items;

            arr.map(function(v, i) {
                return param['d.offerData[' + e.target.dataset.index + '].items[' + i + '][1]'] = false;
            });
            param['d.offerData[' + e.target.dataset.index + '].items[' + e.target.dataset.cur + '][1]'] = true;

        }else{
            let cur = 'd.offerData[' + e.target.dataset.index + '].items['+ e.target.dataset.cur +'][1]';
            console.log(cur)
            if(this.data.d.offerData[e.target.dataset.index].items[e.target.dataset.cur][1]){
                 param[cur] = false
            }else{
                param[cur] = true
            }
        }

        this.setData(param);
    },
    bindinput: function(e){
        let param = {};
        let self = this;
        this.data.d.offerInput.map(function(v,i) {
            if (v.id == e.currentTarget.id) {
                v.value = e.detail.value;
            }
        });

        param['d.offerInput'];
        self.setData(param);
    },
    offerTap: function(e){ //获取报价
        let arr = [],
        self = this;
        if (this.data.d.offerData != undefined) {
            this.data.d.offerData.map(function(v) {
                if(v.type == 0) {
                    let item_name = v.name
                    v.items.map(function(v,i) {
                        if(v[1] == true){
                           arr.push(item_name+':'+v[0]); 
                        }
                    });
                } else {
                    let item_name = v.name
                    let new_item  = []
                    v.items.map(function(v,i) {
                        if(v[1] == true){
                           new_item.push(v[0]);
                        }
                    });
                    arr.push(item_name+':'+new_item);
                }
            });
        };


        if (this.data.d.offerInput != undefined) {
            this.data.d.offerInput.map(function(v) {
                if(v.value) {
                    arr.push(v.name+':'+v.value);
                }
            });
        };

        let offer_url = '/pages/appointment?baojiaType=baojia&remark='+arr.join(";")
        wx.navigateTo({
            url: offer_url
        })
    },
    likeTap: function(e){ //客照点赞
        for (let i = 0; i < this.data.d.imageData.length; i++) {
            if( this.data.d.imageData[i].id == e.currentTarget.id ){
                let param = {};

                if(this.data.d.imageData[i].active != true){
                    param['d.imageData['+i+'].like'] = this.data.d.imageData[i].like + 1;
                    param['d.imageData['+i+'].active'] = true;
                    this.setData(param);

                    wx.request({
                        url: 'http://127.0.0.1',
                        data: {
                            id: e.currentTarget.id,
                            num: param['d.imageData['+i+'].like']
                        },
                        method: 'POST',
                        success: function(d){
                            wx.showModal({
                                content: '谢谢点赞',
                                showCancel: false
                            })
                        }

                    })
                }
            }
        }
    },
    onReachBottom: function(){
        let page_data = this.data.d;
        let gid       = page_data.gid ? page_data.gid : '';
        let keywords  = page_data.keywords ? page_data.keywords : '';
        if(this.data.d.has_more == true) {
            //防止重复、先直接设置FALSE，等返回值再设置
            this.data.d.has_more = false;
            let kv = '';
            if(this.data.currentId == 'show') {
                kv = 'keywords='+keywords
            } else {
                kv = 'gid='+gid;
            }
            let param = {
                API_URL: getApp().globalData.yt_base_url+'getTypeData.html?pageType='+this.data.currentId+'&domain='+getApp().globalData.extInfo.domain+'&'+kv+'&p='+page_data.p
            };
            
            newData.result(param).then( data => {
                let resultData         = data.data.data;
                console.log(resultData);
                page_data.p            = resultData.p //设置页面
                page_data.has_more     = resultData.has_more //是否还有更多
                page_data.p_last_index = resultData.p_last_index //是否还有更多
                if (resultData.imageData != undefined) {
                    resultData.imageData.map(function(v) {
                        if(v) {
                            page_data.imageData.push(v);
                        }
                    });
                };
                this.data.d.p = resultData.p

                this.setData({
                    d: page_data,
                })

            }).catch(e => {
                console.error(e);
            });
        }
    },
    swiperChange: function(e){
        if(e.detail.current+1 == this.data.d.p_last_index && this.data.d.has_more){
            this.onReachBottom();
        }
    },
    onReady: function(){
        let that = this
        getApp().initNav(function() {
            that.setData({
                global: getApp().globalData.d(),
                'global.currentId': that.data.currentId
            })
        })

    },
    onShareAppMessage: function(res) { //分享功能
        if (res.from === 'button') {
            return {
                title: this.data.title,
                path: res.target.dataset.url,
                success: function(res) {
                    // 转发成功
                },
                fail: function(res) {
                    // 转发失败
                }
            }
        }

        return {
            title:  this.data.title,
            path: '/pages/index?go='+this.data.global.currentId,
            success: function(res) {
                // 转发成功
            },
            fail: function(res) {
                // 转发失败
            }
        }
    }
})