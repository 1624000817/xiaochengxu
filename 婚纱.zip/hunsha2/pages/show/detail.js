import newData from '../../Datas/m.js';

Page({
    data:{
      imgurl: []
    },

    phoneTap: function(e){ //拨打电话
        getApp().globalData.phone(e);
    },
    onLoad: function(params){

      var L = this.data.imgurl.length;
      this.setData({
        all: L
      })



        let _this = this;
        let param = {
            API_URL: getApp().globalData.yt_base_url+'getTypeData.html?pageType=show_detail&domain='+getApp().globalData.extInfo.domain+'&id='+params.id
        };
        
        newData.result(param).then( data => {
            let datas = data.data.data;

            this.setData({
                d: datas,
                global: getApp().globalData.d(),
                'global.link': true,
                'global.currentId': 'show'
            })

            wx.setNavigationBarTitle({
                title: this.data.d.title
            })

        }).catch(e => {
            console.error(e);
        });
    },
    onReady: function(){

    },
    onShareAppMessage: function(res) {
        if (res.from === 'button') {

        }
        return {
            title: this.data.d.title,
            //path: '/page/user?id=123',
            success: function(res) {
                // 转发成功
            },
            fail: function(res) {
                // 转发失败
            }
        }
    }
})