import newData from '../Datas/m.js';

Page({
    data:{
        currentId: 'appointment',
    },
    phoneTap: function(e){ //拨打电话
        getApp().globalData.phone(e);
    },
    onLoad: function(params){
        let _this = this;
        let param = {
            API_URL: getApp().globalData.yt_base_url+'getTypeData.html?pageType=baojia&domain='+getApp().globalData.extInfo.domain+'&baojiaType='+params.baojiaType+'&remark='+params.remark
        };
        
        newData.result(param).then( data => {
            let datas = data.data.data;

            this.setData({
                d: datas,
                global: getApp().globalData.d(),
                'global.link': true,
                'global.currentId': 'appointment'
            })

            wx.setNavigationBarTitle({
                title: this.data.d.title
            })

        }).catch(e => {
            console.error(e);
        });
    },
    appointmentForm: function(e){ //提交报价信息
        if(e.detail.value.name == false || e.detail.value.name == undefined ){
            wx.showModal({
                content: '请输入'+e.detail.value.name_alias,
                showCancel: false
            })
            return;
        };
        if(!/^(13[0-9]|15[0-9]|18[0-9]|14[0-9]|17[0-9])\d{8}$/.test(e.detail.value.mobile)){
            wx.showModal({
                content: e.detail.value.mobile_alias+'错误！',
                showCancel: false
            })
            return;
        };

        wx.showLoading({
          title: '提交中',
          mask: true
        })
        wx.request({
            url: getApp().globalData.yt_base_url+'saveBaojia.html?domain='+getApp().globalData.extInfo.domain,
            data: e.detail.value,
            header: {
                'content-type': 'application/x-www-form-urlencoded'
              },
            method: 'POST',
            success: function(res){
                wx.hideLoading()
                if(res.data.status == true) {
                   wx.showModal({
                        content: '提交成功！我们会尽快联系您！',
                        showCancel: false
                    })
                } else {
                  wx.showModal({
                    title: '提交失败！',
                    content: res.data.message,
                    showCancel: true,
                  })
                }
            },
            fail: function(d){
                wx.showModal({
                    content: d.errMsg,
                    showCancel: false
                })
            }
        })

    },
    onReady: function(){
 
    },
    onShareAppMessage: function(res) {
        if (res.from === 'button') {
            // 来自页面内转发按钮
        }
        return {
            title: this.data.d.title,
            //path: '/page/user?id=123',
            success: function(res) {
                // 转发成功
            },
            fail: function(res) {
                // 转发失败
            }
        }
    }
})